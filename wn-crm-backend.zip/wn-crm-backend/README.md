# WN CRM - MongoDB Deployment Guide

## Quick Start

### 1. Backend Deployment (Render/Railway - Free)

**Option A: Deploy to Render (Recommended)**
1. Go to https://render.com
2. Sign up (free)
3. Click "New +" → "Web Service"
4. Connect your GitHub repo OR upload backend folder
5. Settings:
   - Name: `wn-crm-api`
   - Environment: `Node`
   - Build Command: `npm install`
   - Start Command: `npm start`
6. Add Environment Variables:
   - `MONGO_URI` = `mongodb+srv://wn-crm-admin:Pocketfm%402026@wn-crm-cluster.8aj7nkf.mongodb.net/?retryWrites=true&w=majority`
   - `JWT_SECRET` = `your-secret-key-here-change-this`
7. Click "Create Web Service"
8. Wait 2-3 minutes for deployment
9. Copy the URL (e.g., `https://wn-crm-api.onrender.com`)

**Option B: Deploy to Railway**
1. Go to https://railway.app
2. Sign up with GitHub
3. Click "New Project" → "Deploy from GitHub repo"
4. Add environment variables same as above
5. Deploy and copy URL

### 2. Frontend Deployment (Netlify)

1. Update `WN_CRM_Master.jsx`:
   - Replace `API_URL` with your backend URL
2. Build for production:
   ```bash
   npm run build
   ```
3. Drag `build` folder to Netlify
4. Done!

### 3. First Time Setup

1. Open your deployed frontend
2. Register first user (becomes admin)
3. Import your authors CSV
4. Start using!

## Architecture

```
Frontend (Netlify)  →  Backend API (Render)  →  MongoDB Atlas
   React.jsx            Express/Node.js           Cloud Database
```

## Features

✅ Multi-user support
✅ Real-time sync across devices
✅ Secure authentication (JWT)
✅ Cloud database (MongoDB Atlas)
✅ Auto-save on every change
✅ Import/Export CSV
✅ Activity log
✅ Dashboard analytics

## Security Notes

- Change JWT_SECRET in production
- Enable IP whitelist in MongoDB Atlas for production
- Use HTTPS only (Netlify/Render provide this free)

## Support

For issues, check:
1. Backend logs in Render dashboard
2. Browser console for frontend errors
3. MongoDB Atlas metrics for database issues
